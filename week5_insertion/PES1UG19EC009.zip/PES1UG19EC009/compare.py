import matplotlib.pyplot as plt

data=[32,64,96,128,160,192,224,256]
insert_count=[]  # Declare an empty list 
insert_time=[]
bubble_count=[]
bubble_time=[]
select_count=[]
select_time=[]

def my_function():
    x=1;                                         # x keeps track of line count
    for myline in myfile:                        # each line is stored as myline,
        if(x==1): 
            insert_count.append(float(myline))   # add its contents to mylines.
        elif(x==2): 
            insert_time.append(float(myline))  
        elif(x==3):
            bubble_count.append(float(myline))   
        elif(x==4):
            bubble_time.append(float(myline)) 
        elif(x==5):
            select_count.append(float(myline))  
        elif(x==6):
            select_time.append(float(myline)) 
        x=x+1  
  
                                          
with open ('op_32.txt', 'rt') as myfile:        # Open file for reading text data
    my_function()
myfile.close();

with open ('op_64.txt', 'rt') as myfile:       
    my_function()
myfile.close();

with open ('op_96.txt', 'rt') as myfile:        
    my_function()
myfile.close();

with open ('op_128.txt', 'rt') as myfile:        
    my_function()
myfile.close();

with open ('op_160.txt', 'rt') as myfile:        
    my_function()
myfile.close();

with open ('op_192.txt', 'rt') as myfile:        
    my_function()
myfile.close();

with open ('op_224.txt', 'rt') as myfile:        
    my_function()
myfile.close();

with open ('op_256.txt', 'rt') as myfile:     
    my_function()
myfile.close();           
                      
#use matplotlib or gnuplot
plt.subplot(3, 2, 1)
plt.plot(data,insert_count)
plt.title("Insertion Sort")
plt.xlabel("Data size")
plt.ylabel("No. of Comparisons")

plt.subplot(3, 2, 2)
plt.plot(data,insert_time)
plt.title("Insertion Sort")
plt.xlabel("Data size")
plt.ylabel("Run time")

plt.subplot(3, 2, 3)
plt.plot(data,bubble_count)
plt.title("Bubble Sort")
plt.xlabel("Data size")
plt.ylabel("No. of Comparisons")

plt.subplot(3, 2, 4)
plt.plot(data,bubble_time)
plt.title("Bubble Sort")
plt.xlabel("Data size")
plt.ylabel("Run Time")

plt.subplot(3, 2, 5)
plt.plot(data,select_count)
plt.title("Selection Sort")
plt.xlabel("Data size")
plt.ylabel("No. of Comparisons")

plt.subplot(3, 2, 6)
plt.plot(data,select_time)
plt.title("Selection Sort")
plt.xlabel("Data size")
plt.ylabel("Run Time")

plt.tight_layout()  #increase spacing betwenn subplots
plt.show() 


#Superimposing graphs on one plot

plt.subplot(2,1,1) 
# Plotting both the curves simultaneously 
plt.plot(data, insert_count, 'r', label='Insertion') 
plt.plot(data, bubble_count, 'gs', label='Bubble')
plt.plot(data, select_count, 'b', label='Selection') 
plt.ylabel("No. of comparisons") 
plt.xlabel("Data size") 
plt.title("Comparison") 
plt.legend()

plt.subplot(2,1,2) 
plt.plot(data, insert_time, 'r', label='Insertion') 
plt.plot(data, bubble_time, 'g', label='Bubble')
plt.plot(data, select_time, 'b', label='Selection') 
plt.ylabel("Run Time") 
plt.xlabel("Data size") 
plt.title("Time Complexity") 
plt.legend()

plt.tight_layout() 
plt.show() 

