#include <stdio.h>
#include <stdlib.h>
#include "session5_sort.h"
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
    double t;
    t = (end.tv_sec - start.tv_sec);                  
    t += (end.tv_nsec - start.tv_nsec) * 0.000000001; 
    return t;
}

int main(){
        FILE *fptr = fopen("session5_sort_ip_rand256k.txt","r"); 
        int numtrials = 0;
        fscanf(fptr, "%d", &numtrials);
        Record *arr1 = malloc(sizeof(Record)*numtrials); 
        Record *arr2 = malloc(sizeof(Record)*numtrials);
        Record *arr3 = malloc(sizeof(Record)*numtrials);
        for(int k=0; k<numtrials; ++k){
                fscanf(fptr,"%ld",&arr1[k].serialnumber); 
                fscanf(fptr,"%d",&arr1[k].score);
                arr2[k].serialnumber = arr1[k].serialnumber;
                arr2[k].score = arr1[k].score;
                arr3[k].serialnumber = arr2[k].serialnumber;
                arr3[k].score = arr2[k].score;
        }
        
        FILE *fp1=fopen("op_256.txt","w");
	if(fp1==NULL)
	{
		printf("Cant open file");
		return 0;}
        
        struct timespec start, end; 

        clock_gettime(CLOCK_REALTIME, &start); 
        long int count = InsertionSort(arr1, numtrials);
        clock_gettime(CLOCK_REALTIME, &end);
    
        printf("%ld\t",count);
        printf("%lf sec spent on InsertionSort()\n",time_elapsed(start, end));               
        fprintf(fp1,"%ld\n%lf\n",count,time_elapsed(start, end)); // data is written into file only after file closes fclose, till then stored in buffer. Sometimes u can even use f1.flush() before fclose
        
        
        clock_gettime(CLOCK_REALTIME, &start); 
        count = BubbleSort(arr2, numtrials); 
        clock_gettime(CLOCK_REALTIME, &end); 
    
        printf("%ld\t",count);
        printf("%lf sec spent on BubbleSort()\n",time_elapsed(start, end));            
        fprintf(fp1,"%ld\n%lf\n",count,time_elapsed(start, end));
        
        
        clock_gettime(CLOCK_REALTIME, &start); 
        count = SelectionSort(arr3, numtrials); 
        clock_gettime(CLOCK_REALTIME, &end); 
    
        printf("%ld\t",count);
        printf("%lf sec spent on SelectionSort()\n",time_elapsed(start, end));
	fprintf(fp1,"%ld\n%lf\n",count,time_elapsed(start, end));
	
	fclose(fp1);
        fclose(fptr);
   
    return 0; 
}
